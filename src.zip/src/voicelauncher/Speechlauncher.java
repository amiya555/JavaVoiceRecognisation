/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voicelauncher;

//Imports
import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.api.LiveSpeechRecognizer;
import edu.cmu.sphinx.api.SpeechResult;
import edu.cmu.sphinx.api.StreamSpeechRecognizer;
import edu.cmu.sphinx.result.WordResult;

import java.io.FileInputStream;
import java.io.IOException;


/**
 *
 * @author ex094
 */
public class Speechlauncher {
    public static void main(String[] args) throws IOException {
        //Configuration Object
        Configuration configuration = new Configuration();

     // Set path to acoustic model.
        configuration.setAcousticModelPath("resource:/edu/cmu/sphinx/models/en-us/en-us");
        // Set path to dictionary.
        configuration.setDictionaryPath("resource:/edu/cmu/sphinx/models/en-us/cmudict-en-us.dict");
        // Set language model.
        configuration.setLanguageModelPath("resource:/edu/cmu/sphinx/models/en-us/en-us.lm.bin");
        
        /*StreamSpeechRecognizer recognizer = new StreamSpeechRecognizer(configuration);
        recognizer.startRecognition(new FileInputStream("C://Users//Amiya//Downloads//Music//yes-2.wav"));*/
        
        LiveSpeechRecognizer recognizer = new LiveSpeechRecognizer(configuration);
         // Start recognition process pruning previously cached data.
         recognizer.startRecognition(true);

        SpeechResult result = recognizer.getResult();
        configuration.setSampleRate(8000);
        
        while ((result = recognizer.getResult()) != null) {
            System.out.println(result.getHypothesis());   
        }
        
        // Print utterance string without filler words.
      //Get the recognized speech
        String command = result.getHypothesis();
        String work = null;
        System.out.println(command);

        // Get individual words and their times.
        for (WordResult r : result.getWords()) {
            System.out.println(r);
   
        if(command.equalsIgnoreCase("open search")) {
            work = "google-chrome http://www.google.com";
    	}
    	else if(command.equalsIgnoreCase("and")) {
            System.out.println("Opening Calculator!");
        }
        }
        // Save lattice in a graphviz format.
        result.getLattice().dumpDot("lattice.dot", "lattice");
        
    }
    
}
