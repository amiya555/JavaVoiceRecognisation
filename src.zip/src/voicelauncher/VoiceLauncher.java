/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voicelauncher;

//Imports
import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.api.LiveSpeechRecognizer;
import edu.cmu.sphinx.api.SpeechResult;
import java.io.IOException;


/**
 *
 * @author ex094
 */
public class VoiceLauncher {
    public static void main(String[] args) throws IOException {
        //Configuration Object
        Configuration configuration = new Configuration();

     // Set path to acoustic model.
        configuration.setAcousticModelPath("resource:/edu/cmu/sphinx/models/en-us/en-us");
        // Set path to dictionary.
        configuration.setDictionaryPath("resource:/edu/cmu/sphinx/models/en-us/cmudict-en-us.dict");
        // Set language model.
        configuration.setLanguageModelPath("resource:/edu/cmu/sphinx/models/en-us/en-us.lm.bin");
        
        //Recognizer object, Pass the Configuration object
        LiveSpeechRecognizer recognize = new LiveSpeechRecognizer(configuration);
        
        //Start Recognition Process (The bool parameter clears the previous cache if true)
        recognize.startRecognition(true);
        
        /*SpeechResult result = recognize.getResult();
        // Pause recognition process. It can be resumed then with startRecognition(false).
        recognize.stopRecognition();
        */
        
        //Creating SpeechResult object
        SpeechResult result;
        
        //Check if recognizer recognized the speech
        while ((result = recognize.getResult()) != null) {
            
            //Get the recognized speech
            String command = result.getHypothesis();
            String work = null;
            Process p;
            
            //Some Extra Commands from my Corpus File
            if(command.equalsIgnoreCase("open search")) {
                work = "google-chrome http://www.google.com";
            } else if (command.equalsIgnoreCase("new tab")) {
                work = "google-chrome \\c";
            } else if (command.equalsIgnoreCase("open mail")) {
                work = "google-chrome gmail.com";
            } else if (command.equalsIgnoreCase("open linked in")) {
                work = "google-chrome linkedin.com";
            } else if (command.equalsIgnoreCase("open blog")) {
                work = "google-chrome procurity.wordpress.com";
            } else if (command.equalsIgnoreCase("open git hub")) {
                work = "google-chrome github.com/Ex094";
            } else if (command.equalsIgnoreCase("browser")) {
                work = "google-chrome";
            } else if (command.equalsIgnoreCase("terminal")) {
                work = "gnome-terminal";
            } else if (command.equalsIgnoreCase("file manager")) {
                work = "nautilus";
        	}  else if (command.equalsIgnoreCase("open browser")) {
        		work = "C://Program Files (x86)//Google//Chrome//Application//chrome.exe";
        	}
        	else if(command.equalsIgnoreCase("calculator")) {
                System.out.println("Opening Calculator!");
            }
            
            if(work != null) {
                p = Runtime.getRuntime().exec(work);
            }
        }
        
    }
    
}
